package com.appzorro.driverappcabscout.model;

import com.google.android.gms.maps.model.LatLng;

/**
 * Created by vijay on 2/5/17.
 */

public class ConfigVariable {

   public static double dbtimefare=1,dbdistancefare=0.05,dbbasefare=20,dbtoatl;

   public static LatLng customer_source,customer_destination;
}
