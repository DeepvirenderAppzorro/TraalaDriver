package com.appzorro.driverappcabscout.controller;

/**
 * Created by vijay on 28/2/17.
 */

public class FareDetailManager {




}
