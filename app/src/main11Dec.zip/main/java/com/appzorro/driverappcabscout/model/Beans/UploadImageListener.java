/*
package com.appzorro.driverappcabscout.model.Beans;

import android.widget.Toast;

import com.appzorro.driverappcabscout.view.MainActivity;

*/
/**
 * Created by vijay on 4/8/18.
 *//*


public class UploadImageListener  implements
        SocialAuthListener {

    @Override
    public void onError(SocialAuthError e) {
    }

    @Override
    public void onExecute(String arg0, Integer arg1) {
        Integer status = arg1;
        try {
            if (status.intValue() == 200 || status.intValue() == 201
                    || status.intValue() == 204) {
                Toast.makeText(MainActivity.this, "Image Uploaded",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Image not Uploaded",
                        Toast.LENGTH_SHORT).show();
            }

        } catch (NullPointerException e) {
            Toast.makeText(MainActivity.this, "Image not Uploaded",
                    Toast.LENGTH_SHORT).show();
        }
    }
}*/
